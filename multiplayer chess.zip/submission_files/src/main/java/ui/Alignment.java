package ui;

/**
 * @author Juyas
 * @version 07.11.2021
 * @since 07.11.2021
 */
public enum Alignment {

    TOP,
    LEFT,
    BOTTOM,
    RIGHT,
    CENTER

}