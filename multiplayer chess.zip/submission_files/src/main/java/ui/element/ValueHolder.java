package ui.element;

/**
 * @author Juyas
 * @version 07.11.2021
 * @since 07.11.2021
 */
public interface ValueHolder {

    float getValue();

    void setValue(float newValue);

}