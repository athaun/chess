package ui.element;

/**
 * @author Juyas
 * @version 07.11.2021
 * @since 07.11.2021
 */
public interface TextHolder {

    String getText();

    void setText(String newText);

}