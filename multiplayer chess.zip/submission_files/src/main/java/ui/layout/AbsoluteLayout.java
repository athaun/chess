package ui.layout;

import ui.Container;

/**
 * @author Juyas
 * @version 10.11.2021
 * @since 10.11.2021
 */
public class AbsoluteLayout implements ContainerLayout {

    @Override
    public void updateComponents(Container container) {
        //empty - does not apply any changes to the components
    }

}