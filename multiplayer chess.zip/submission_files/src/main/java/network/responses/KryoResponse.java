package network.responses;

public class KryoResponse {
    public String text;
}
