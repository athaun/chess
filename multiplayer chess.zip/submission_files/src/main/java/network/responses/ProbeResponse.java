package network.responses;

public class ProbeResponse extends KryoResponse {
    public int gameID;
    public boolean open;
    public String hostName;
}