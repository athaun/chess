package network.requests;

/*
 * This class is used to send a join request to the server.
 */
public class JoinRequest extends KryoRequest {
    public String name;
}
