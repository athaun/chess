package network.requests;

public class KryoRequest {
    public String text;
}