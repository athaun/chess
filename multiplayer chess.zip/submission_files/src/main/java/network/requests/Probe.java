package network.requests;

public class Probe extends KryoRequest {
    public String text = "PROBE";
}
