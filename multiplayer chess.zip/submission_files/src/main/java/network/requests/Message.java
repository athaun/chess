package network.requests;

public class Message extends KryoRequest {
    
}
