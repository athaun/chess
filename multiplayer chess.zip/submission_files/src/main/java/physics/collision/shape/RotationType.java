package physics.collision.shape;

/**
 * @author Juyas
 * @version 21.07.2021
 * @since 21.07.2021
 */
public enum RotationType {

    AROUND_CENTER,
    AROUND_ORIGIN,
    AROUND_POINT;

}