### Credits and attributions for media and assets in Azurite
* Lines of code was created by Trevor Lentz and made available under the Creative Commons Attribution-ShareAlike 3.0 Unported [(CC BY-SA 3.0) license](https://creativecommons.org/licenses/by-sa/3.0/
). Downloaded from Trevor Lentz's [OpenGameart page](https://opengameart.org/content/lines-of-code)
* Button texture - StumpyStrust on [OpenGameArt.org](https://opengameart.org/content/ui-button)
* Tilesets used in the demo scenes were created by 0x72 on itch.io [Ts 1](https://0x72.itch.io/16x16-dungeon-tileset) and [Ts 2](https://0x72.itch.io/dungeontileset-ii)
* RPG GUI assets from [https://opengameart.org/content/rpg-gui-construction-kit-v10](https://opengameart.org/content/rpg-gui-construction-kit-v10)