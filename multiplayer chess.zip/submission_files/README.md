## Chess

### Credits
Created by Asher Haun, Silvia Flores, Ellie Walser and Younus Syed

Most of the files are for the azurite engine which is our graphics framework.
The files for chess are in `src/main/java/network`
and in `src/main/java/scenes`
The entry point is `src/main/java/scenes`

### Running

```
cd chess
gradle execute
```

Or import into intellj/eclipse as a gradle project.